For 5.x, the source code in this folder is actually used from the `dropbox-sdk-java` module.

In 6.x versions, we will have a standalone Android artifact, and that is why this folder is split apart.